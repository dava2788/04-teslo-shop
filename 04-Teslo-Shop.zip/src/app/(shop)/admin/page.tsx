
export default function AdminPage() {
  return (
    <div>
      <h1>Admin Page</h1>
    </div>
  );
}